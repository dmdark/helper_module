<?php
define('_SEO_DIRECTORY', dirname(__FILE__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR);
define('_BLOCKS_DIRECTORY', dirname(__FILE__) . '/blocks/');