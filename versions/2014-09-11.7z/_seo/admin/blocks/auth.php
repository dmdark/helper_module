<!-- Авторизация -->
<div class="container">
	<div class="row">
		<form class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3" action="" method="post">
			<h2>Вход в панель</h2>
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Login" name="login" autofocus/>
			</div>
			<div class="form-group">
				<input type="password" class="form-control" placeholder="Password" name="password"/>
			</div>
			<button type="submit" class="btn btn-default">Войти</button>
		</form>
	</div>
</div>